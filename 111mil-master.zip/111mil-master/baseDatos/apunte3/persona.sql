CREATE TABLE persona (
    dni                  integer,
    nombre          text
);

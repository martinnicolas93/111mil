-- Contar la cantidad de propiedades registradas en la base.

SELECT 
	count(1)
FROM
	property;